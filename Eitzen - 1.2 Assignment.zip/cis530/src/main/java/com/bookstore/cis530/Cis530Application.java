package com.bookstore.cis530;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cis530Application {

	public static void main(String[] args) {
		SpringApplication.run(Cis530Application.class, args);
	}

}
